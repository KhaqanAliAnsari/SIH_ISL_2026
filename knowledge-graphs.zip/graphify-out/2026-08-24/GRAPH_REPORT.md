# Graph Report - SIH_ISL_2026  (2026-08-24)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 2681 nodes · 5969 edges · 146 communities (114 shown, 32 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 136 edges (avg confidence: 0.86)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `853dc1be`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- _read_text
- _make_id
- Path
- resolution.py
- watch.py
- cache.py
- reflect.py
- cli.py
- analyze.py
- serve.py
- build.py
- dispatch_install_cli
- export.py
- llm.py
- hooks.py
- VideoPanel.tsx
- extract_files_direct
- symbol_resolution.py
- App.tsx
- write_callflow_html
- Path
- Gemini API Key Management
- __main__.py
- _call_claude_cli
- Bash and C# Extraction
- prs.py
- DTW Template Pipeline
- make_id
- _call_llm
- build_merge
- install.py
- scip_ingest.py
- generate_section_flowchart
- detect.py
- CsharpNameResolver
- callflow_html.py
- diagnostics.py
- ingest.py
- Path
- extract.py
- security.py
- compilerOptions
- Counter
- detect
- dependencies
- pick_text
- objc.py
- mcp_ingest.py
- global_graph.py
- multigraph_compat.py
- affected.py
- MinHash
- transcribe.py
- edge_data
- cluster.py
- save_manifest
- _is_ignored
- sentenceEngine.ts
- semantic_cleanup.py
- dedup.py
- html.py
- google_workspace.py
- _ImageRef
- default_graph_json
- devDependencies
- deduplicate_entities
- graphify CLI tool
- _always_on
- _build_server
- dtwWorker.ts
- verilog.py
- tree_html.py
- _ip_is_blocked
- file_slice.py
- attach_graph_impact
- resolver_registry.py
- package.json
- benchmark.py
- _norm
- _load_graph
- SignKYC — Bank Official Console
- Authentication and Supabase
- PhrasedSentenceStrip.tsx
- Graphify Pipeline
- graphify (OpenCode)
- Backend Environment Dependencies
- first_present
- introspect_cargo
- _is_sensitive
- paths.py
- _collision_rank
- _query_terms
- mem0-memory/package.json
- normalize_sections
- humanize_label
- _platform_skill_destination
- index.mjs
- _StageTimer
- _UF
- _looks_like_context_exceeded
- pascal_resolution.py
- introspect_postgres
- Incremental Update and Cluster-Only (AMP)
- _uninstall_claude_hook
- _ApiKeyMiddleware
- graphify skill-agents
- update_config.cjs
- graphify/__init__.py
- safe_fetch
- _QueryScores
- Graphify Skill Definition
- Add URL and Watch Folder (AMP)
- Incremental Update
- vercel.json
- _remap_hyperedge_members
- _cut_lines_to_budget
- Transcription Pipeline
- react-dom
- graphify save-result
- graphify.serve
- react
- Constrained Query Expansion
- Video/Audio Transcription Flow
- Extractor Migration Playbook
- graphify (Generic)
- graphify (Pi)
- graphify (Trae)
- graphify (VSCode)
- Git Hooks and Agent Integration
- FastDTW
- 106-dim Feature Vector
- ISL DTW README
- MediaPipe Holistic
- Customer Side Modal
- Extraction Subagent Prompt (AMP)
- GitHub Clone and Cross-Repo Merge (AMP)
- Commit Hook and AGENTS.md Integration (AMP)
- Commit Hook and CLAUDE.md Integration (Claude)
- Extraction Subagent Prompt Compact (Claw)
- Graph Exports

## God Nodes (most connected - your core abstractions)
1. `_read_text()` - 122 edges
2. `dispatch_command()` - 115 edges
3. `_make_id()` - 112 edges
4. `_file_stem()` - 75 edges
5. `_rebuild_code()` - 54 edges
6. `_extract_generic()` - 40 edges
7. `extract()` - 37 edges
8. `dispatch_install_cli()` - 35 edges
9. `write_callflow_html()` - 32 edges
10. `_collect_js_symbol_resolution_facts()` - 31 edges

## Surprising Connections (you probably didn't know these)
- `Video Panel` --shares_data_with--> `Sentence Engine`  [INFERRED]
  README.md → needToDone.md
- `_extract_generic()` --uses--> `LanguageConfig`  [INFERRED]
  .agents/skills/graphify/extractors/engine.py → .agents/skills/graphify/extractors/models.py
- `deduplicate_entities()` --uses--> `MinHash`  [INFERRED]
  .agents/skills/graphify/dedup.py → .agents/skills/graphify/_minhash.py
- `_get_extractor()` --indirect_call--> `extract_blade()`  [INFERRED]
  .agents/skills/graphify/extract.py → .agents/skills/graphify/extractors/blade.py
- `_extract_pascal_regex()` --calls--> `_add_edge()`  [INFERRED]
  .agents/skills/graphify/extractors/pascal.py → .agents/skills/graphify/mcp_ingest.py

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **AI Recognition Pipeline** — readme_videopanel, needtodone_sentenceengine, needtodone_gemini_api [EXTRACTED 0.90]
- **Graphify Core Pipeline** — agents_skills_graphify_skill, agents_skills_graphify_skills_agents_references_extraction_spec, agents_skills_graphify_skills_agents_references_update [EXTRACTED 0.90]
- **Graphify Maintenance & Automation** — skills_droid_references_update_incremental_update, skills_kilo_references_hooks_git_integration, skills_kilo_references_github_and_merge_cross_repo_merge [EXTRACTED 0.90]
- **KYC Workflow Loop** — readme_videopanel, readme_aiassistpanel, readme_kycprogressstrip, needtodone_auditmodal [EXTRACTED 0.95]
- **Graphify Agent Skill Implementations** — agents_skills_graphify_skill_copilot, agents_skills_graphify_skill_devin, agents_skills_graphify_skill_droid, agents_skills_graphify_skill_kilo, agents_skills_graphify_skill_kiro [EXTRACTED 1.00]
- **Graphify Always-On Instructions** — agents_skills_graphify_always_on_agents_md, agents_skills_graphify_always_on_antigravity_rules, agents_skills_graphify_always_on_claude_md, agents_skills_graphify_always_on_gemini_md, agents_skills_graphify_always_on_kiro_steering, agents_skills_graphify_always_on_vscode_instructions [EXTRACTED 1.00]
- **Graphify Pipeline Components** — graphify_detect, agents_skills_graphify_extract, agents_skills_graphify_build, agents_skills_graphify_cluster, graphify_analyze, graphify_report, graphify_export, graphify_cache, graphify_diagnostics, graphify_cli [EXTRACTED 1.00]
- **Graphify Skill Set (AMP)** — skills_amp_references_add_watch, skills_amp_references_exports, skills_amp_references_extraction_spec, skills_amp_references_github_and_merge, skills_amp_references_hooks, skills_amp_references_query, skills_amp_references_transcribe, skills_amp_references_update [EXTRACTED 1.00]
- **Graphify Skill Platform Variants** — agents_skills_graphify_skill_agents, agents_skills_graphify_skill_aider, agents_skills_graphify_skill_amp, agents_skills_graphify_skill_claw, agents_skills_graphify_skill_codex [EXTRACTED 1.00]
- **Graphify Platform Variants** — agents_skills_graphify_skill_opencode_graphify, agents_skills_graphify_skill_pi_graphify, agents_skills_graphify_skill_trae_graphify, agents_skills_graphify_skill_vscode_graphify, agents_skills_graphify_skill_windows_graphify, agents_skills_graphify_skill_graphify [INFERRED 0.90]

## Communities (146 total, 32 thin omitted)

### Community 0 - "_read_text"
Cohesion: 0.02
Nodes (168): _get_c_func_name(), _import_js(), _import_lua(), _import_swift(), Emit module-level ``imports`` edges and report the imported modules. A Swift…, Recursively unwrap declarator to find the innermost identifier (C)., Extract require('module') from Lua variable_declaration nodes., _read_text() (+160 more)

### Community 1 - "_make_id"
Cohesion: 0.03
Nodes (136): extract_lazarus_package(), _import_java(), _import_php(), _import_scala(), Extract package metadata from Lazarus .lpk package files (XML format). .lpk is…, extract_apex(), Path, Apex extractor. Moved verbatim from graphify/extract.py. (+128 more)

### Community 2 - "Path"
Cohesion: 0.03
Nodes (87): _augment_cpp_string_tests(), _emit_rescued_import(), extract_astro(), extract_c(), extract_cpp(), extract_groovy(), extract_java(), extract_js() (+79 more)

### Community 3 - "resolution.py"
Cohesion: 0.05
Nodes (85): _augment_js_reexport_edges(), extract(), extract_vue(), Extract imports, symbols, and type refs from a ``.vue`` SFC. Masks the…, Compatibility wrapper for the JS/TS symbol-resolution post-pass., Extract AST nodes and edges from a list of code files. Two-pass process: 1.…, _SymbolResolutionFacts, _apply_symbol_resolution_facts() (+77 more)

### Community 4 - "watch.py"
Cohesion: 0.05
Nodes (70): dedupe_edges(), dedupe_nodes(), _is_ast_tier(), _load_existing_graph(), Load (nodes, edges, hyperedges, directed) from an existing graph.json for an…, AST vs semantic tier. _origin wins when present; unstamped legacy items…, Collapse nodes sharing an ``id``, last-writer-wins on attributes. Mirrors what…, Collapse exact parallel edges by ``(source, target, relation)``, keeping the… (+62 more)

### Community 5 - "cache.py"
Cohesion: 0.06
Nodes (66): _absolutize_ids_in(), _absolutize_source_files_in(), _body_content(), cache_dir(), cached_files(), cached_word_count(), check_semantic_cache(), _cleanup_stale_ast_entries() (+58 more)

### Community 6 - "reflect.py"
Cohesion: 0.06
Nodes (63): _log_path(), log_query(), _log_responses(), nodes_from_result(), Any, Path, Query logging for graphify — append-only JSONL, fail-silent., Append one JSONL record to the query log. Never raises. (+55 more)

### Community 7 - "cli.py"
Cohesion: 0.06
Nodes (62): print_benchmark(), Print a human-readable benchmark report., Measure token reduction: corpus tokens vs graphify query tokens. Args:…, run_benchmark(), distinct_repo_tags(), Return a unique, human-meaningful repo tag per input graph for merge-graphs.…, _clone_repo(), _default_graph_path() (+54 more)

### Community 8 - "analyze.py"
Cohesion: 0.08
Nodes (45): _cross_community_surprises(), _cross_file_surprises(), _cross_language(), _file_category(), find_import_cycles(), god_nodes(), graph_diff(), _is_concept_node() (+37 more)

### Community 9 - "serve.py"
Cohesion: 0.10
Nodes (44): _bfs(), _complete_induced_edges(), _compute_idf(), _dfs(), _display_graph_path(), _filter_graph_by_context(), _find_node(), find_node_ambiguity() (+36 more)

### Community 10 - "build.py"
Cohesion: 0.07
Nodes (41): build(), build_from_json(), _coerce_hyperedge_member_refs(), _coerce_id(), _coerce_non_string_ids(), deduplicate_by_label(), disambiguate_file_labels_in_nodes(), _disambiguate_file_node_labels() (+33 more)

### Community 11 - "dispatch_install_cli"
Cohesion: 0.09
Nodes (41): _agents_platform_uninstall(), _agents_uninstall(), _amp_uninstall(), _antigravity_uninstall(), claude_uninstall(), codebuddy_uninstall(), _cursor_uninstall(), dispatch_install_cli() (+33 more)

### Community 12 - "export.py"
Cohesion: 0.08
Nodes (41): attach_hyperedges(), backup_if_protected(), _cap_filename(), _cypher_escape(), _cypher_label(), _dedup_node_filenames(), existing_graph_node_count(), _git_head() (+33 more)

### Community 13 - "llm.py"
Cohesion: 0.07
Nodes (37): _backend_supports_vision(), _community_label_lines(), detect_backend(), generate_community_labels(), _get_tokenizer(), _label_batch_with_retry(), label_communities(), _label_identifiers() (+29 more)

### Community 14 - "hooks.py"
Cohesion: 0.11
Nodes (36): _detached_launch(), _git_root(), _has_merge_attr(), _hooks_dir(), install(), _install_hook(), _load_graphifyrc(), _merge_attr_line() (+28 more)

### Community 15 - "VideoPanel.tsx"
Cohesion: 0.11
Nodes (31): TemplateRecorderModal(), TemplateRecorderModalProps, KEY_LANDMARKS, VideoPanel(), cachedTemplateNames, clearBuffer(), encodeNpy(), FEATURE_DIM (+23 more)

### Community 16 - "extract_files_direct"
Cohesion: 0.10
Nodes (36): bisect_slice(), FileSlice, Read just this slice's characters from its parent file., Split a slice into two halves at a newline near its midpoint, or None. Used by…, A contiguous ``[start, end)`` character range of a splittable text file.…, The on-disk path a unit belongs to (the parent file for a slice)., read_slice_text(), unit_path() (+28 more)

### Community 17 - "symbol_resolution.py"
Cohesion: 0.11
Nodes (34): _bash_make_id(), build_label_index(), build_python_symbol_index(), existing_edge_pairs(), _file_node_id_for_path(), find_unique_python_symbol(), ImportedSymbol, iter_raw_calls() (+26 more)

### Community 18 - "App.tsx"
Cohesion: 0.12
Nodes (23): AppView, AIAssistPanel(), AIAssistPanelProps, AuditModal(), AuditModalProps, CustomerSideModal(), CustomerSideModalProps, EditFieldModal() (+15 more)

### Community 19 - "write_callflow_html"
Cohesion: 0.09
Nodes (30): CallflowOptions, classify_edges(), first_list(), html_comment_text(), infer_project_name(), load_graph(), load_labels(), load_report() (+22 more)

### Community 20 - "Path"
Cohesion: 0.12
Nodes (31): _agents_install(), _agents_platform_install(), _amp_install(), _canonical_platform(), _copy_skill_file(), _cursor_install(), _devin_rules_install(), gemini_install() (+23 more)

### Community 21 - "Gemini API Key Management"
Cohesion: 0.10
Nodes (9): buildPhraseCacheKey(), CacheEntry, GeminiKeyPool, geminiPool, GenerateOptions, KeyState, LRUCache, app (+1 more)

### Community 22 - "__main__.py"
Cohesion: 0.09
Nodes (29): _amp_legacy_cleanup(), _devin_rules_uninstall(), _install_kilo_plugin(), _kilo_config_path(), _kilo_config_write_path(), _load_json_like(), _print_banner(), Remove .windsurf/rules/graphify.md. (+21 more)

### Community 23 - "_call_claude_cli"
Cohesion: 0.10
Nodes (30): _azure_client(), _backend_pkg_hint(), _call_azure(), _call_bedrock(), _call_claude(), _call_claude_cli(), _call_openai_compat(), _claude_cli_supports_json_schema() (+22 more)

### Community 24 - "Bash and C# Extraction"
Cohesion: 0.09
Nodes (27): _import_csharp(), _import_kotlin(), _bash_assignment_base(), _bash_source_suffix(), extract_bash(), Path, Bash extractor. Moved verbatim from graphify/extract.py., Extract functions, source imports, and cross-function calls from a .sh file. (+19 more)

### Community 25 - "prs.py"
Cohesion: 0.23
Nodes (24): bold(), _c(), _ci_icon(), _classify(), cmd_prs(), cyan(), dim(), green() (+16 more)

### Community 26 - "DTW Template Pipeline"
Cohesion: 0.14
Nodes (24): compute_dtw_distance(), load_templates(), ndarray, Load all .npy files in TEMPLATES_DIR. Groups them into a dictionary by gesture…, Compute DTW distance between two feature sequences., run_pipeline(), draw_overlay(), main() (+16 more)

### Community 27 - "make_id"
Cohesion: 0.10
Nodes (22): make_id(), normalize_id(), Single source of truth for node-ID normalization. Three independent producers…, r"""Normalize a single ID string to its canonical form. Guarantees, all…, Build a canonical node ID from one or more name parts. Parts are joined with…, _coerce_deps(), extract_package_manifest(), _parse_apm() (+14 more)

### Community 28 - "_call_llm"
Cohesion: 0.09
Nodes (26): _anthropic_response_text(), _backend_env_keys(), _bedrock_inference_config(), _bedrock_response_text(), _call_llm(), _claude_cli_envelope(), _claude_cli_error(), _default_model_for_backend() (+18 more)

### Community 29 - "build_merge"
Cohesion: 0.13
Nodes (25): _abs_identity(), build_merge(), _build_prune_sets(), _derive_prune_root(), graph_has_legacy_ids(), _has_global_id(), _infer_merge_root(), merge_raw_extraction() (+17 more)

### Community 30 - "install.py"
Cohesion: 0.15
Nodes (24): _claude_pretooluse_hooks(), _gemini_hook(), _install_claude_hook(), _install_codebuddy_hook(), _install_codex_hook(), _install_gemini_hook(), _kilo_uninstall(), _kilo_uninstall_global() (+16 more)

### Community 31 - "scip_ingest.py"
Cohesion: 0.14
Nodes (24): _build_scip_metadata(), _coerce_str(), _emit_relationships(), _emit_symbol_node(), _first_occurrence_line(), ingest_scip_json(), _is_true(), _make_scip_node_id() (+16 more)

### Community 32 - "generate_section_flowchart"
Cohesion: 0.11
Nodes (24): generate_overview_graph(), generate_section_flowchart(), group_nodes_by_file(), mermaid_class_defs(), mermaid_init(), mermaid_section_id(), node_kind(), node_label() (+16 more)

### Community 33 - "detect.py"
Cohesion: 0.12
Nodes (23): classify_file(), _env_command_args(), FileType, _is_graphable_source(), _looks_like_paper(), _match_anchored_ignore_pattern(), Match an anchored gitignore pattern without letting ``*`` cross ``/``., # NOTE: aws_credentials/gcloud_credentials/service_account moved to the (+15 more)

### Community 34 - "CsharpNameResolver"
Cohesion: 0.16
Nodes (14): _build_csharp_type_def_index(), CsharpNameResolver, _is_cs_file(), _metadata(), Path, C# cross-file resolution. The config-driven C# *extractor* (``extract_csharp``…, Namespace/using/alias-aware C# simple-name resolution. Factored out of…, Return deterministic ``(namespace, name) -> node_id`` C# type definitions. (+6 more)

### Community 35 - "callflow_html.py"
Cohesion: 0.11
Nodes (22): build_community_index(), build_section_node_map(), _community_text(), derive_sections_from_communities(), detect_lang(), generate_header(), generate_nav(), _keyword_score() (+14 more)

### Community 36 - "diagnostics.py"
Cohesion: 0.19
Nodes (22): _canonical_edge(), _count_extra(), diagnose_extraction(), diagnose_file(), _edge_list(), _exact_signature(), format_diagnostic_json(), format_diagnostic_report() (+14 more)

### Community 37 - "ingest.py"
Cohesion: 0.16
Nodes (22): _detect_url_type(), _download_binary(), _fetch_arxiv(), _fetch_html(), _fetch_tweet(), _fetch_webpage(), _html_to_markdown(), ingest() (+14 more)

### Community 38 - "Path"
Cohesion: 0.15
Nodes (22): _auto_follow_symlinks(), convert_office_file(), count_words(), docx_to_markdown(), extract_pdf_text(), _file_within_size_cap(), _md5_file(), _os_path() (+14 more)

### Community 39 - "extract.py"
Cohesion: 0.04
Nodes (87): _canonicalize_csharp_namespace_nodes(), _check_tree_sitter_version(), extract_csharp(), extract_csproj(), extract_slnx(), extract_xaml(), _is_top_level_function_definition(), _kotlin_package_index() (+79 more)

### Community 40 - "security.py"
Cohesion: 0.11
Nodes (15): _max_graph_file_bytes(), _NoFileRedirectHandler, Path, urllib handler that routes http:// through _SSRFGuardedHTTPConnection., urllib handler that routes https:// through _SSRFGuardedHTTPSConnection., Redirect handler that re-validates every redirect target. Prevents open-…, Resolve *path* and verify it stays inside *base*. *base* defaults to the…, Return the graph.json size cap in bytes. Honors the… (+7 more)

### Community 41 - "compilerOptions"
Cohesion: 0.09
Nodes (21): DOM, DOM.Iterable, ES2022, node, vite/client, compilerOptions, allowImportingTsExtensions, allowJs (+13 more)

### Community 42 - "Counter"
Cohesion: 0.12
Nodes (21): derive_flow_chain(), edge_score(), generate_overview_cards(), node_degree_scores(), node_importance(), preferred_edges(), Counter, Aggregate inter-section edge counts and relation names. (+13 more)

### Community 43 - "detect"
Cohesion: 0.13
Nodes (21): detect(), _find_vcs_root(), _git_info_exclude(), _git_tracked_path_keys(), ignored_predicate(), _is_regular_file(), _load_dir_own_ignore(), _load_graphifyignore() (+13 more)

### Community 44 - "dependencies"
Cohesion: 0.10
Nodes (21): express, @google/genai, lucide-react, @mediapipe/tasks-vision, motion, dependencies, express, @google/genai (+13 more)

### Community 45 - "pick_text"
Cohesion: 0.13
Nodes (20): _describe_node(), format_node_refs(), generate_call_table_rows(), generate_section_cards(), generate_section_intro(), is_zh(), pick_text(), Render node references as readable labels instead of internal IDs. (+12 more)

### Community 46 - "objc.py"
Cohesion: 0.13
Nodes (19): _import_c(), _cpp_declarator_name(), _cpp_local_var_types(), Return the bare variable name from a C++ declaration declarator, unwrapping…, Collect ``var -> ClassName`` from local variable declarations in a C++ function…, _semantic_reference_edge(), _source_location(), extract_objc() (+11 more)

### Community 47 - "mcp_ingest.py"
Cohesion: 0.17
Nodes (19): _add_edge(), _add_node(), _detect_package_from_args(), _emit_server(), extract_mcp_config(), is_mcp_config_path(), _make_id(), Any (+11 more)

### Community 48 - "global_graph.py"
Cohesion: 0.20
Nodes (18): prune_repo_from_graph(), Remove all nodes tagged with repo_tag from G in-place. Returns count removed., _file_hash(), global_add(), global_list(), global_path(), global_remove(), _load_global_graph() (+10 more)

### Community 49 - "multigraph_compat.py"
Cohesion: 0.19
Nodes (15): _build_probe_graph(), CapabilityCheck, _check(), MultigraphCapabilityResult, _probe_duplicate_key_overwrite_semantics(), _probe_keyed_parallel_edges(), probe_multigraph_capabilities(), _probe_node_link_round_trip() (+7 more)

### Community 50 - "affected.py"
Cohesion: 0.26
Nodes (16): affected_nodes(), AffectedHit, _as_repo_relative(), _bare_name(), format_affected(), _format_location(), load_graph(), _node_label() (+8 more)

### Community 51 - "MinHash"
Cohesion: 0.15
Nodes (11): _lsh_integrate(), _mh_coeffs(), MinHash, MinHashLSH, _optimal_lsh_params(), ndarray, MinHash + band-LSH — datasketch-compatible drop-in (no scipy). datasketch.lsh…, MinHash sketch — same API as datasketch.MinHash for the subset used here. (+3 more)

### Community 52 - "transcribe.py"
Cohesion: 0.18
Nodes (16): Raise ValueError if *url* is not http or https, or targets a private/internal…, validate_url(), build_whisper_prompt(), download_audio(), _get_whisper(), _get_yt_dlp(), is_url(), _model_name() (+8 more)

### Community 53 - "edge_data"
Cohesion: 0.23
Nodes (15): edge_data(), Return one edge attribute dict for (u, v), tolerating MultiGraph. For…, _community_article(), _cross_community_links(), _god_node_article(), _index_md(), _md_link(), Graph (+7 more)

### Community 54 - "cluster.py"
Cohesion: 0.22
Nodes (15): cluster(), cohesion_score(), label_communities_by_hub(), _partition(), Graph, Community detection on NetworkX graphs. Uses Leiden (graspologic) if available,…, Context manager to suppress stdout/stderr during library calls. graspologic's…, Run Leiden community detection. Returns {community_id: [node_ids]}. Community… (+7 more)

### Community 55 - "save_manifest"
Cohesion: 0.17
Nodes (15): detect_incremental(), load_manifest(), _mtime_may_hide_a_rewrite(), _nfc(), NFC-normalize a path string used as a manifest key. On macOS, ``os.walk`` /…, Return ``key`` as a forward-slash relative path from ``root``. Keys outside…, Inverse of :func:`_to_relative_for_storage`. Re-anchor a stored key against…, Load the manifest from a previous run. Returns {} on any error. When ``root``… (+7 more)

### Community 56 - "_is_ignored"
Cohesion: 0.13
Nodes (16): _has_coverage_artifacts(), _has_venv_markers(), _is_ignored(), _is_noise_dir(), _is_scan_ignored(), _path_identity(), Portable comparison key for an existing filesystem path., Return True if the path should be ignored per .graphifyignore patterns. Uses… (+8 more)

### Community 57 - "sentenceEngine.ts"
Cohesion: 0.20
Nodes (15): App(), clearIdleTimer(), DispatchReason, dispatchSentence(), getCurrentTokens(), getEngineState(), initSentenceEngine(), isStopGesture() (+7 more)

### Community 58 - "semantic_cleanup.py"
Cohesion: 0.19
Nodes (14): _normalize_hyperedge_members(), Canonicalize a hyperedge's member list onto the `nodes` key, in place. If…, _append_rationale_attr(), _is_sentence_like_rationale_label(), load_validated_semantic_fragment(), Path, Load and validate a semantic chunk, rejecting oversize files before parsing.…, Clean up a semantic extraction fragment in-place. Operations: 1. Removes nodes… (+6 more)

### Community 59 - "dedup.py"
Cohesion: 0.15
Nodes (14): _content_token_swap(), _is_code(), _make_minhash(), _merge_missing_attributes(), Entity deduplication pipeline for graphify knowledge graphs. Pipeline: exact…, True when tokens x and y read as one word misspelt, not two words (#2576). A…, True when two equal-token-count labels differ in at least one swapped content…, True for AST-extracted code symbols. Code-node identity is the node ID (which… (+6 more)

### Community 60 - "html.py"
Cohesion: 0.18
Nodes (13): Shared constants/helpers for the graphify exporters package. Symbols used by…, _html_document_title(), _html_script(), _html_styles(), _hyperedge_script(), Graph, html — moved verbatim from graphify/export.py., Return a portable label for the graph.html <title>. Tracked artifacts must not… (+5 more)

### Community 61 - "google_workspace.py"
Cohesion: 0.24
Nodes (14): convert_google_workspace_file(), _extract_file_id_from_url(), _extract_resource_key(), Any, Path, Optional Google Workspace shortcut export support. Google Drive for desktop…, Export a Google Workspace shortcut to a Markdown sidecar. Returns the converted…, Extract a Drive file ID from common Google Docs/Drive URL shapes. (+6 more)

### Community 62 - "_ImageRef"
Cohesion: 0.17
Nodes (13): _anthropic_content(), _bedrock_content(), _image_notes(), _ImageRef, _openai_content(), A single image destined for a vision request. `raw` is None when the image is…, Return refs with pixel data dropped (for non-vision backends)., Text block listing the images so the model emits one node per image. Always… (+5 more)

### Community 63 - "default_graph_json"
Cohesion: 0.15
Nodes (13): default_graph_json(), Default ``graph.json`` path under the configured output dir. The package-wide…, _build_http_app(), _filter_blank_stdin(), _main(), _MCPASGIApp, Filter blank lines from stdin before MCP reads it. Some MCP clients (Claude…, Start the MCP server over stdio (the default, per-developer transport). (+5 more)

### Community 64 - "devDependencies"
Cohesion: 0.13
Nodes (15): autoprefixer, esbuild, devDependencies, autoprefixer, esbuild, tailwindcss, tsx, @types/express (+7 more)

### Community 65 - "deduplicate_entities"
Cohesion: 0.20
Nodes (14): _crossfile_fileanchored_blocked(), deduplicate_entities(), _is_variant_pair(), _llm_tiebreak(), _numeric_tokens_differ(), _pick_winner(), Block label-based merging of file-anchored non-code nodes across files (#1284).…, Deduplicate near-identical entities in a knowledge graph. Args: nodes: list of… (+6 more)

### Community 66 - "graphify CLI tool"
Cohesion: 0.15
Nodes (13): graphify rules, graphify always-on agents-md, graphify always-on antigravity-rules, graphify always-on claude-md, graphify always-on gemini-md, graphify always-on kiro-steering, graphify always-on vscode-instructions, graphify command-kilo (+5 more)

### Community 67 - "_always_on"
Cohesion: 0.18
Nodes (13): _always_on(), claude_install(), codebuddy_install(), _install_skill_references(), Atomically install a packaged references/ sidecar next to SKILL.md. Stages the…, Write the graphify section to the local CLAUDE.md., Install the graphify skill and CODEBUDDY.md section for CodeBuddy., Read a packaged always-on instruction block from graphify/always_on/. The six… (+5 more)

### Community 68 - "_build_server"
Cohesion: 0.21
Nodes (13): _detect_default_branch(), fetch_prs(), fetch_worktrees(), format_prs_text(), _gh(), _parse_ci(), Auto-detect the repo's default branch via gh, then git, then fall back to…, Plain-text PR summary for MCP output (no ANSI). (+5 more)

### Community 69 - "dtwWorker.ts"
Cohesion: 0.19
Nodes (11): dtwCurrRow, dtwDistance(), dtwPrevRow, euclideanDistanceSq(), fillSnapshot(), GestureTemplateClass, GestureVariation, matchGesture() (+3 more)

### Community 70 - "verilog.py"
Cohesion: 0.24
Nodes (10): _augment_systemverilog_semantics(), extract_verilog(), Path, Verilog extractor. Moved verbatim from graphify/extract.py., First `simple_identifier` under node in pre-order, or None. tree-sitter-verilog…, Extract modules, functions, tasks, package imports, instantiations, and…, _sv_collect_type_refs(), _sv_first_identifier() (+2 more)

### Community 71 - "tree_html.py"
Cohesion: 0.38
Nodes (9): build_tree(), _common_root(), emit_html(), _make_truncation_leaf(), Any, Path, tree_html — emit a D3 v7 collapsible-tree HTML view of a graph. A self-…, Build a ``{name, total_count, children}`` hierarchy. Each leaf is either a code… (+1 more)

### Community 72 - "_ip_is_blocked"
Cohesion: 0.17
Nodes (10): _ip_is_blocked(), Resolve *host* once and return (family, validated_ip) for the first address…, HTTPConnection that resolves + validates DNS once, then connects to the exact…, HTTPSConnection variant of _SSRFGuardedHTTPConnection. Connects to the…, Return True if *ip* falls in a private/reserved/internal range. Shared by…, _resolve_and_validate(), _SSRFGuardedHTTPConnection, _SSRFGuardedHTTPSConnection (+2 more)

### Community 73 - "file_slice.py"
Cohesion: 0.25
Nodes (10): _best_cut(), expand_oversized_files(), is_splittable_text(), Path, Intra-file slicing for oversized text documents (#1369). The extraction packer…, Replace each oversized splittable-text file with a list of ``FileSlice``s.…, True for plain-text document types that may be sliced., Return a cut index in ``(start, end]`` at the strongest nearby boundary.… (+2 more)

### Community 74 - "attach_graph_impact"
Cohesion: 0.20
Nodes (11): attach_graph_impact(), build_community_labels(), compute_pr_impact(), fetch_pr_files(), _load_graph_json(), _path_match(), Path, True if graph_src and pr_file refer to the same file (path-boundary safe). (+3 more)

### Community 75 - "resolver_registry.py"
Cohesion: 0.24
Nodes (10): LanguageResolver, Path, Registry for cross-file, language-specific resolution passes. Some…, One cross-file, language-specific resolution pass. ``resolve`` has the…, Append a resolver to the global registry and return it (for inline use)., Return a copy of the registered resolvers, in registration order., Run every resolver whose suffix appears in ``paths``. Behaviorally identical to…, register() (+2 more)

### Community 76 - "package.json"
Cohesion: 0.18
Nodes (10): name, private, scripts, build, clean, dev, lint, start (+2 more)

### Community 77 - "benchmark.py"
Cohesion: 0.24
Nodes (9): _estimate_tokens(), _hr(), Graph, _query_subgraph_tokens(), Token-reduction benchmark - measures how much context graphify saves vs naive…, Return unicode_char if stdout can encode it, else ascii_fallback. Windows…, Horizontal rule that survives non-UTF-8 stdout (e.g. Windows cp1252 console)., Run BFS from best-matching nodes and return estimated tokens in the subgraph… (+1 more)

### Community 78 - "_norm"
Cohesion: 0.20
Nodes (10): _defines_id(), _entropy(), _id_prefixes(), _norm(), Lowercase + collapse non-alphanumeric runs to space (Unicode-aware)., The ID prefixes a node extracted from ``source_file`` may legitimately mint. An…, True when the node's own source_file is the file its ID encodes. A doc that…, Shannon entropy in bits/char of the normalised label. (+2 more)

### Community 79 - "_load_graph"
Cohesion: 0.22
Nodes (7): _communities_from_graph(), _GraphContextCache, _load_graph(), Thread-safe graph contexts: one pinned default plus an LRU of projects., Build one entry for an already-resolved path and known file key.…, Return a fresh context, retaining project contexts by LRU order.…, Reconstruct community dict from community property stored on nodes.

### Community 80 - "SignKYC — Bank Official Console"
Cohesion: 0.22
Nodes (10): Audit Modal, Gemini API, Sentence Engine, Supabase, AI Assist Panel, Indian Sign Language (ISL), KYC Progress Strip, SignKYC — Bank Official Console (+2 more)

### Community 81 - "Authentication and Supabase"
Cohesion: 0.36
Nodes (7): Login(), LoginProps, Registration(), RegistrationProps, isSupabaseConfigured, supabase, Customer

### Community 82 - "PhrasedSentenceStrip.tsx"
Cohesion: 0.38
Nodes (9): PhrasedSentenceStrip(), PhrasedSentenceStripProps, VideoPanelProps, getStopGestureName(), manualDispatch(), SentenceEngineCallbacks, PhrasedSentence, SentenceEngineState (+1 more)

### Community 83 - "Graphify Pipeline"
Cohesion: 0.22
Nodes (9): Graphify Skill (Copilot), Graphify Skill (Devin), Graphify Skill (Droid), Graphify Skill (Kilo), Graphify Skill (Kiro), AST Extraction, Graphify Pipeline, Graphify Query (+1 more)

### Community 84 - "graphify (OpenCode)"
Cohesion: 0.39
Nodes (9): graphify (OpenCode), graphify (Windows), graphify.analyze, graphify.cache, graphify.cli, graphify.detect, graphify.diagnostics, graphify.export (+1 more)

### Community 85 - "Backend Environment Dependencies"
Cohesion: 0.25
Nodes (8): dependencies, dotenv, mem0ai, @modelcontextprotocol/sdk, mem0ai, @modelcontextprotocol/sdk, dotenv, dotenv

### Community 86 - "first_present"
Cohesion: 0.29
Nodes (8): endpoint_id(), first_present(), normalize_edge(), normalize_node(), Return the first non-empty value for any candidate key., Normalize edge endpoints that may be strings or node-like objects., Normalize a graphify node across common graph.json schema variants., Normalize graphify edges while preserving original fields.

### Community 87 - "introspect_cargo"
Cohesion: 0.46
Nodes (7): introspect_cargo(), _load_toml(), _member_manifest_paths(), Any, Path, Cargo manifest introspection for workspace-internal crate dependencies., Return crate nodes and internal dependency edges from Cargo manifests.

### Community 88 - "_is_sensitive"
Cohesion: 0.25
Nodes (8): _generic_keyword_hit(), _is_env_template(), _is_prose_note(), _is_sensitive(), True for `.env.example` / `.envrc.sample` style committed templates (#2184)., A prose/note file (.md/.rst/...) whose stem is a multi-word topic slug is…, True if a generic secret keyword appears load-bearing in the filename. Secret-…, Return True if this file likely contains secrets and should be skipped.

### Community 89 - "paths.py"
Cohesion: 0.32
Nodes (7): disambiguate_ambiguous_candidates(), _is_test_path(), _path_proximity_winner(), Single source of truth for the graphify output-directory name. The output…, Classify a source path as a test path (case-insensitive, segment-aware). Shared…, Pick the candidate whose source file is closest to the call site.…, Resolve an ambiguous bare-name call to one candidate, or ``None``. Shared god-…

### Community 90 - "_collision_rank"
Cohesion: 0.33
Nodes (7): _collision_rank(), _lifecycle_penalty(), Path, _rank_path(), 0 for active/in-progress paths, 2 for archived/done paths, 1 otherwise. Judged…, The root-relative form of ``source_file`` used for collision ranking. Mirrors…, A total order for choosing the survivor of an ID collision, independent of the…

### Community 91 - "_query_terms"
Cohesion: 0.29
Nodes (7): _has_chinese(), _is_searchable(), _query_terms(), Segment Chinese text and keep the original term for exact matching., True if term is Chinese, non-English, or an English word longer than 2 chars., Split a query into searchable terms, segmenting Chinese text, then drop…, _segment_chinese()

### Community 92 - "mem0-memory/package.json"
Cohesion: 0.33
Nodes (5): description, main, name, type, version

### Community 93 - "normalize_sections"
Cohesion: 0.33
Nodes (6): html_anchor_id(), normalize_communities(), normalize_sections(), Generate a stable, unique HTML anchor ID., Normalize section community lists from JSON or simple strings., Ensure sections have safe unique IDs and an overview section first.

### Community 94 - "humanize_label"
Cohesion: 0.33
Nodes (6): humanize_label(), node_display_name(), Readable node label for tables and summaries., Truncate without splitting Mermaid syntax., Convert graph labels into short labels people can scan in a diagram., truncate_text()

### Community 95 - "_platform_skill_destination"
Cohesion: 0.33
Nodes (6): _antigravity_finalize(), _antigravity_install(), _platform_skill_destination(), Install graphify for Google Antigravity (global skill + .agents/rules +…, Return the skill destination for a platform and scope., Write Antigravity's always-on layer next to an installed skill. Injects the…

### Community 96 - "index.mjs"
Cohesion: 0.40
Nodes (4): __dirname, MEMORY_FILE, server, transport

### Community 99 - "_looks_like_context_exceeded"
Cohesion: 0.40
Nodes (5): _looks_like_context_exceeded(), _looks_like_timeout(), Heuristically classify an exception as a context-window overflow. Different…, Classify an exception as a recognized subprocess or SDK timeout., BaseException

### Community 100 - "pascal_resolution.py"
Cohesion: 0.50
Nodes (4): _pascal_raw_calls(), Cross-file resolution for Pascal/Delphi calls to inherited methods. The per-…, Resolve Pascal/Delphi calls to a method inherited across file boundaries.…, resolve_pascal_inherited_calls()

### Community 101 - "introspect_postgres"
Cohesion: 0.50
Nodes (4): introspect_postgres(), _quote_ident(), Connect to PostgreSQL, reconstruct DDL, and extract via extract_sql()., Double-quote a PostgreSQL identifier, escaping embedded double-quotes.

### Community 102 - "Incremental Update and Cluster-Only (AMP)"
Cohesion: 0.40
Nodes (5): graphify.build.build_merge, graphify.detect.detect_incremental, graphify.transcribe.transcribe_all, Transcribe Video and Audio (AMP), Incremental Update and Cluster-Only (AMP)

### Community 103 - "_uninstall_claude_hook"
Cohesion: 0.50
Nodes (4): Remove the graphify PreToolUse hook from .claude/settings.json and its local-…, Drop graphify PreToolUse hooks from a single Claude settings file, if present., _strip_graphify_hook(), _uninstall_claude_hook()

### Community 105 - "graphify skill-agents"
Cohesion: 0.50
Nodes (4): graphify skill-agents, graphify skill-amp, graphify reference: exports, graphify reference: github-and-merge

### Community 108 - "safe_fetch"
Cohesion: 0.33
Nodes (6): _build_opener(), Fetch *url* and return raw bytes. Protections applied: - URL scheme validated…, Fetch *url* and return decoded text (UTF-8, replacing bad bytes). Wraps…, safe_fetch(), safe_fetch_text(), OpenerDirector

### Community 109 - "_QueryScores"
Cohesion: 0.67
Nodes (3): _QueryScores, Per-query scoring result, returned by the private `_score_query` helper.…, NamedTuple

### Community 110 - "Graphify Skill Definition"
Cohesion: 0.67
Nodes (3): Graphify Skill Definition, Extraction Specification, Query and Traversal Logic

### Community 111 - "Add URL and Watch Folder (AMP)"
Cohesion: 0.67
Nodes (3): graphify.ingest, graphify.watch, Add URL and Watch Folder (AMP)

### Community 112 - "Incremental Update"
Cohesion: 0.67
Nodes (3): Incremental Update, Cross-Repo Merge, Git & Claude Integration

## Knowledge Gaps
- **150 isolated node(s):** `TemplateRecorderModalProps`, `AppView`, `CustomerSideModalProps`, `FooterControlsProps`, `InterpreterModalProps` (+145 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **32 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `dispatch_command()` connect `cli.py` to `resolution.py`, `watch.py`, `cache.py`, `reflect.py`, `analyze.py`, `serve.py`, `build.py`, `export.py`, `llm.py`, `hooks.py`, `extract_files_direct`, `write_callflow_html`, `__main__.py`, `_call_claude_cli`, `prs.py`, `_call_llm`, `build_merge`, `diagnostics.py`, `ingest.py`, `detect`, `global_graph.py`, `affected.py`, `edge_data`, `cluster.py`, `save_manifest`, `semantic_cleanup.py`, `html.py`, `_build_server`, `tree_html.py`, `_load_graph`, `introspect_cargo`, `_StageTimer`, `introspect_postgres`?**
  _High betweenness centrality (0.093) - this node is a cross-community bridge._
- **Why does `extract()` connect `resolution.py` to `_make_id`, `Path`, `CsharpNameResolver`, `watch.py`, `cache.py`, `extract.py`, `cli.py`, `resolver_registry.py`, `symbol_resolution.py`, `paths.py`?**
  _High betweenness centrality (0.045) - this node is a cross-community bridge._
- **Why does `_file_stem()` connect `_make_id` to `_read_text`, `Path`, `resolution.py`, `verilog.py`, `extract.py`, `build.py`, `objc.py`, `mcp_ingest.py`, `symbol_resolution.py`, `Bash and C# Extraction`, `build_merge`?**
  _High betweenness centrality (0.038) - this node is a cross-community bridge._
- **Are the 5 inferred relationships involving `dispatch_command()` (e.g. with `to_html()` and `_file_hash()`) actually correct?**
  _`dispatch_command()` has 5 INFERRED edges - model-reasoned connections that need verification._
- **What connects `TemplateRecorderModalProps`, `AppView`, `CustomerSideModalProps` to the rest of the system?**
  _150 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `_read_text` be split into smaller, more focused modules?**
  _Cohesion score 0.018948999718230487 - nodes in this community are weakly interconnected._
- **Should `_make_id` be split into smaller, more focused modules?**
  _Cohesion score 0.025155204386035638 - nodes in this community are weakly interconnected._